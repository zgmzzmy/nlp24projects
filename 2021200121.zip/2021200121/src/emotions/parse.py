import tushare as ts
import pandas as pd
import numpy as np
import datetime
import os
from snownlp import SnowNLP

def from_tt_to_strp(ori:int):
    return datetime.datetime.strptime(str(ori),'%Y%m%d')
    
class DataEngine:
    def __init__(self, stock, source, exchange = 'SH',start = '20240101',end='20241115'):
        self.stock = stock
        self.source = source
        if 'index' in stock or ~stock.isdigit():
            isindex = True
        else:
            isindex = False
        self.isindex = isindex
        self.exchange = exchange
        self.source = self.load_source()
        pro = ts.pro_api('b482e100ae55ddc5f51edabf3513a299f14e60d9453b9baa02377f4b')
        if isindex is False:
            exchanges = ['SH','SZ']
            for i in exchanges:
                label = pro.daily(ts_code=f'{stock}.{i}', start_date=start, end_date=end)
                if len(label)==0:
                    continue
                else:
                    self.exchange = i
                    break
        else:
            exchanges = ['SH','SZ']
            for i in exchanges:
                label = pro.index_daily(ts_code=f'{stock[4:]}.{i}', start_date=start, end_date=end)
                if len(label)==0:
                    continue
                else:
                    self.exchange = i
                    break
        label = label.sort_values('trade_date')
        label['label'] =(label['close'].shift(-1) - label['close'])/label['close'] #np.log(1+ label['close'].pct_change(-1))
        label['day'] = label['trade_date'].apply(from_tt_to_strp)
        self.label = label[['close','open','high','low','vol','amount','label','day']].reset_index()

    def load_source(self, output_path = 'D:/nlp_program/emotions/all_files'):
        all_dic = os.listdir( os.path.join(self.source ,self.stock))
        father = os.path.join(self.source ,self.stock)
        tmp_pd = []
        for ad in all_dic:
            file = pd.read_csv(os.path.join(father,ad))
            tmp_pd.append(file)
        pdd = pd.concat(tmp_pd, axis=0)

        from datetime import datetime
        def convert_to_datetime(date_str):
            full_date_str = f'2024-{date_str}'
            return datetime.strptime(full_date_str, '%Y-%m-%d %H:%M')

        pdd['tradetime'] = pdd['date'].apply(convert_to_datetime)
        #pdd['tradetime'] = pdd['tradetime'].apply(lambda x: str(x))
        pd_to_parse = pdd[['comment_id','content','reply','read','tradetime']]
        son = self.stock
        if self.isindex:
            son = self.stock + '_index_token.csv'
        else:
            son = self.stock +'_token.csv'
        pd_to_parse.to_csv(os.path.join(output_path,son))
        return pd_to_parse

    def preprocess_source(self):
        sub = '看盘用东财，论股用东财，交易用东财；用东方财富，一个APP搞定所有！立即开户>>'
        source = self.source[~self.source['content'].str.contains(sub, na=False)]
        source['tradetime'] = source['tradetime'].apply(lambda x: str(x))
        source['day'] = source['tradetime'].apply(lambda x: datetime.datetime.strptime(x,'%Y-%m-%d %H:%M:%S').date())
        source['time'] = source['tradetime'].apply(lambda x: datetime.datetime.strptime(x,'%Y-%m-%d %H:%M:%S').hour)
        source = source[['content','reply','read','day','time']].reset_index()
        self.source = source
        return self.source
    
    def easy_analyse(self):
        source = self.source
        senti = []
        for s in range(len(source)):
            senti.append(SnowNLP(source['content'][s]).sentiments)
        self.senti = senti
        return senti

    def concat_xy(self):
        self.source['score'] = self.senti
        self.source['final_score'] = (self.source['score']-0.5)
        all_score = \
        pd.DataFrame(
        {
            'score':(self.source[['final_score','day']].sort_values('day').groupby('day').mean()\
                *self.source[['final_score','day']].sort_values('day').groupby('day').count()/\
                    self.source[['final_score','day']].sort_values('day').groupby('day').std())['final_score'],
            'score_read':self.source[['read','day']].sort_values('day').groupby('day').mean()['read'],
            'score_reply':self.source[['reply','day']].sort_values('day').groupby('day').mean()['reply'],
            'final_score': self.source[['final_score','day']].sort_values('day').groupby('day').mean()['final_score'],
        })
        self.label['intraday'] = (self.label['close'].shift(-1) - self.label['open'].shift(-1))/self.label['open'].shift(-1) 
        self.label['jump'] = (self.label['open'].shift(-1) - self.label['close'])/self.label['close']
        y = self.label[['close','open','high','low','vol','amount','label','day','jump','intraday']].reset_index().set_index('day')
        xy = y.join(all_score).dropna().iloc[:-1,:]
        self.dataset = xy
        ic = np.corrcoef(xy['label'],xy['score'])[0][1]
        print(f'IC: {ic}; nums {len(xy)}')
        return xy

    def get_nearest_return(self, save = True, \
        train_path = 'D:/nlp_program/emotions/all_files/train_dataset'):
        # 后期可以控制读取多少天的return label
        source = self.source
        label = self.label
        source['day'] = pd.to_datetime(source['day'])
        label['day'] = pd.to_datetime(label['day'])
        # 对label表按日期排序
        label = label.sort_values(by='day').reset_index(drop=True)
        source['label'] = None
        # 遍历source表中的每一行
        for i, row in source.iterrows():
            nearest_days = label[label['day'] > row['day']]
            if not nearest_days.empty:
                nearest_day = nearest_days.iloc[0]
                # 将对应的收益率赋值给结果列
                source.at[i, 'label'] = nearest_day['label']
            else:
                # 如果没有找到匹配的日期，可以设置一个默认值或跳过
                source.at[i, 'label'] = None  # 或者你可以设置一个默认值
        if save:
            k = f'{self.stock}_xy.csv'
            son = os.path.join(train_path, k)
            source.to_csv(son)
        self.train_data = source
        return source