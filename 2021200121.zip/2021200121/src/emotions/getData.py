import requests
from bs4 import BeautifulSoup
import multiprocessing
import SQL
import time
import sys
import re
import os
import pandas as pd
sys.setrecursionlimit(1000000)

def getHtml(url):#下载网页源代码
    header = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36'}
    try:
        r=requests.get(url,headers=header)
        r.encoding='utf-8'
        r.raise_for_status()
        return r.text
    except:
        return 0

def getDate(origin):#在网页源码中获得评论发表日期，格式：'YY-mm-dd'
    if origin.find('div', {'class':'update'}) is None and origin.find('div', {'class':'update pub_time'})==None:
        return None
    if origin.find('div', {'class':'update'}) is not None:
        return origin.find('div', {'class':'update'}).get_text(strip=True)
    else:
        return origin.find('div', {'class':'update pub_time'}).get_text(strip=True)

def getLikeCount(commentHtml):#在网页源码中获得特定评论的点赞人数
    soup = BeautifulSoup(commentHtml, "html.parser")
    if soup.find("span", {"class": 'likemodule'})==None:
        return None
    if soup.find("span", {"class": 'likemodule'}).get_text(strip=True).strip('“”').isdigit():
        return int(soup.find("span", {"class": 'likemodule'}).get_text(strip=True).strip('“”'))
    else:
        return 0


def from_chi_to_eng(ori_num:str):
    if ori_num.isnumeric():
        return float(ori_num)
    else:
        if '万' in ori_num:
            match = float(re.search(r'\d+\.\d+', ori_num).group[0])
            return match * 1e4
        if '亿' in ori_num:
            match = float(re.search(r'\d+\.\d+', ori_num).group[0])
            return match * 1e8
        else:
            return '0'

def getUserinfo(userHtml):#在网页源码中获得用户粉丝数
    if userHtml==0:
        return 0
    soup = BeautifulSoup(userHtml, "html.parser")
    sub1 = soup.find('div',{'id':'tapage'})#.find_all('p')
    print(sub1.find_all('div',{'class':'others_level'}))
    with open('user.html','w',encoding='utf-8') as file:
            file.write(userHtml)
    return

def get_reply_and_read(url):
    reply = url.find('div',{'class':'reply'}).get_text(strip=True)
    read = url.find('div',{'class':'read'}).get_text(strip=True)
    return reply,read


def getAndStoreInf(html,share_code):
    soup = BeautifulSoup(html, "html.parser")
    contain = soup.find_all("tr", {"class":'listitem'})#获取每条评论节点
    comments = []
    #print(contain)
    for i in contain:
        try:    
                content = i.find('div',{'class':'title'})
                text = i.find('div',{'class':'title'}).string
                #获取评论标题。因东方财富网股吧中大部分用户只发表简短的评论，其标题和内容一致，为简化，只爬取标题。
                contentUrl="http://guba.eastmoney.com"+content.find('a').attrs['href']#内容详情页面
                commentId=content.find('a').attrs['href'][-14:-5]
                userUrl = "https:"+ i.find('div',{'class':'author'}).find('a').attrs["href"]
                
                if contentUrl.__contains__("qa") or contentUrl.__contains__("cfhpl"):#排除问答等内容，只保留用户评论
                    continue
                if userUrl=="http://guba.eastmoney.com/list,jjdt.html":#排除基金动态资讯
                    continue
                date=getDate(i)#获取评论发表时间
                if date==None:
                    continue
                reply,read = get_reply_and_read(i)
                comment={"comment_id":commentId,
                            "content":text,
                            "reply":reply,
                            'read':read,
                            "date":date,
                            "share_code":share_code}
                comments.append(comment)
                time.sleep(1)
        except Exception as e:
            print(e)
            continue
    return comments

def run(data, shared_state):
    html = getHtml("http://guba.eastmoney.com/list," + data['share_code'] + ",f_" + str(data['page']) + ".html")
    if os.path.isfile(f"D:/nlp_program/emotions/{data['share_code']}/comments_{data['share_code']}_page_{data['page']}.csv"):
        shared_state['refresh'] = 1
        return
    comments = getAndStoreInf(html, data['share_code'])
    father = 'D:/nlp_program/emotions/' + data['share_code']
    if not os.path.exists(father):
        os.mkdir(father)
    if comments:
        df = pd.DataFrame(comments)  # 将评论列表转换为 DataFrame
        df.to_csv(f"D:/nlp_program/emotions/{data['share_code']}/comments_{data['share_code']}_page_{data['page']}.csv", index=False)  # 保存为 CSV 文件
        time.sleep(2)
    print('-------------page-------------' + str(data['page']))
    return

if __name__ == '__main__':
    # 沪深300成分股爬取
    tt = pd.read_csv('component.csv', dtype=str).iloc[:, 1:]
    
    # 使用 Manager 创建一个可以在进程之间共享的字典
    manager = multiprocessing.Manager()
    shared_state = manager.dict({'refresh': 0})
    
    for comp in range(0, 268):
        pool = multiprocessing.Pool(processes=2)  # 多进程并行爬取，提高爬取速率。但进程不可设置过多，否则会被ban.
        for i in range(1, 300, 30):
            print(i)
            share_code = []
            for page in range(i, i + 4):
                share_code.append({'share_code': tt.iloc[comp, :].values[0], 'page': page})
            try:
                pool.starmap(run, [(data, shared_state) for data in share_code])
            except:
                pool.starmap(run, [(data, shared_state) for data in share_code])
            print('-------sleeping-------')
            if shared_state['refresh'] == 1:
                shared_state['refresh'] = 0
                continue
            else:
                time.sleep(30)